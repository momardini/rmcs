<?php

namespace App\Http\Livewire;

use Livewire\Component;

class Recipes extends Component
{

}
