<tr {{ $attributes->merge(['class' => 'bg-white']) }}>
    {{ $slot }}
</tr>
