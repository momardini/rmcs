<div class="flex rounded-md shadow-sm">
    <textarea {{ $attributes }} rows="3" class="form-textarea block w-full transition duration-150 ease-in-out sm:text-sm sm:leading-5"></textarea>
</div>
