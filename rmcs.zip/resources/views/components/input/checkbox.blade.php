<div class="flex rounded-md shadow-sm">
    <input {{ $attributes }}
        type="checkbox"
        class="form-checkbox border-cool-gray-300 block transition duration-150 ease-in-out sm:text-sm sm:leading-5"
    />
</div>
